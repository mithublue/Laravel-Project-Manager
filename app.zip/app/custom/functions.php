<?php

function current_user_can( $cap ){
    return true;
}

//
function get_current_user_id() {
    return '1';
}