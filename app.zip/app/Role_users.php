<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role_users extends Model
{
    //
}
